import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLabel, QMessageBox, QLineEdit, QMainWindow, QDialog, QSpinBox, QSizePolicy
from PyQt5.QtGui import QPixmap, QPainter, QColor, QRegExpValidator
from PyQt5.QtCore import Qt, pyqtSignal, QRegExp

class MessageBoard(QDialog):
    def __init__(self, message):
        super().__init__()
        self.setWindowTitle("Message Board")
        self.setGeometry(200, 100, 600, 400)

        layout = QVBoxLayout()

        label = QLabel(message)
        label.setAlignment(Qt.AlignCenter)

        layout.addWidget(label)
        self.setLayout(layout)

class StrukDialog(QDialog):
    def __init__(self, struk_text):
        super().__init__()
        self.setWindowTitle("Struk Pemesanan")
        self.setGeometry(400, 100, 400, 400)

        layout = QVBoxLayout()
        self.setLayout(layout)

        struk_label = QLabel("=== NOTA PEMESANAN ===")
        struk_label.setAlignment(Qt.AlignCenter)
        struk_label.setStyleSheet("""
            QLabel {
                font-size: 20px;
                color: #333;
                margin-bottom: 1px; /* Ubah nilai margin-bottom sesuai kebutuhan Anda */
            }
        """)

        layout.addWidget(struk_label)


        self.label = QLabel(struk_text, self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("""
               QLabel {
                   font-size: 16px;
                   color: #333;
                   background-color: rgba(255, 255, 255, 150); /* Warna latar belakang transparan */
                   padding: 20px;
                   border: 2px solid #ccc;
                   border-radius: 15px;
               }
           """)

        layout.addWidget(self.label)

        self.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)


    def paintEvent(self, event):
        painter = QPainter(self)
        painter.drawPixmap(self.rect(), QPixmap("Art or_20240512_035641_0000.png"))  # Ganti "struk.jpg" dengan nama file gambar Anda
class CashBankApp(QDialog):
    struk_generated = pyqtSignal(str, str, str, int)
    payment_completed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CashBank Payment")
        self.resize(600, 200)

        layout = QVBoxLayout()

        self.label = QLabel("Silahkan lakukan transaksi "
                            "sebesar Rp150.000 ke (BCA)10000305.", self)
        layout.addWidget(self.label, alignment=Qt.AlignCenter)

        self.entry = QLineEdit(self)
        self.entry.setPlaceholderText("Masukkan Nomor Rekening Pengirim")
        layout.addWidget(self.entry, alignment=Qt.AlignCenter)

        self.label2 = QLabel("Masukkan Nomor Rekening Pengirim!", self)
        layout.addWidget(self.label2, alignment=Qt.AlignCenter)

        self.button = QPushButton("Kirim", self)
        layout.addWidget(self.button, alignment=Qt.AlignCenter)
        self.button.clicked.connect(self.payment_complete)

        self.setLayout(layout)

    def payment_complete(self):
        account_number = self.entry.text()
        if not account_number:
            QMessageBox.warning(self, "Peringatan", "Masukkan nomor rekening.")
            return

        # Memeriksa apakah nomor rekening yang dimasukkan sesuai
        if account_number not in ['100000102', '100000103']:
            QMessageBox.warning(self, "Peringatan", "Nomor rekening tidak valid.")
            return

        self.struk_generated.emit(
            self.parent().username,
            self.parent().waktu_terpilih,
            self.parent().meja_terpilih,
            self.parent().guests
        )
        # Tutup jendela CashBankApp setelah pembayaran selesai
        self.close()
        # Emit sinyal payment_completed saat pembayaran selesai
        self.payment_completed.emit()

class RestoranApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Aplikasi Reservasi Meja di Restoran")
        self.resize(1000, 600)
        self.move(200, 20)

        self.setStyleSheet("font-size: 16px;")

        self.waktu_terpilih = ""
        self.meja_terpilih = ""
        self.struk_dialog = None
        self.cashbank_window = None
        self.message_board = None  # Tambahkan variabel untuk menyimpan referensi ke jendela MessageBoard
        self.initUI()

    def initUI(self):
        # Menyiapkan layout utama
        main_layout = QVBoxLayout(self)

        # Menambahkan label gambar sebagai latar belakang
        background_label = QLabel(self)
        pixmap = QPixmap("DineNow_20240513_114133_0000.png")  # Ganti dengan nama file gambar Anda
        background_label.setPixmap(pixmap)
        background_label.setGeometry(0, 0, self.width(), self.height())  # Menyesuaikan ukuran dengan jendela
        background_label.setScaledContents(True)  # Memastikan gambar diubah ukurannya agar sesuai dengan label
        background_label.lower()  # Mengatur label sebagai latar belakang dengan mendeklarasikan yang terakhir
        main_layout.addWidget(background_label)

        self.label_welcome = QLabel(self)
        self.label_welcome.setText("Selamat datang di Restoran AYCE!")
        self.label_welcome.resize(800, 50)
        self.label_welcome.move(100, 50)
        main_layout.addWidget(self.label_welcome)

        self.label_pilih_waktu = QLabel(self)
        self.label_pilih_waktu.setText("Pilih waktu:")
        self.label_pilih_waktu.resize(100, 30)
        self.label_pilih_waktu.move(100, 100)

        # Atur layout utama ke jendela utama
        central_widget = QWidget(self)
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self.btn_reservasi1 = QPushButton("08.00-10.00", self)
        self.btn_reservasi1.resize(150, 50)
        self.btn_reservasi1.move(100, 150)
        self.btn_reservasi1.clicked.connect(lambda: self.pilihWaktu("08.00-10.00"))

        self.btn_reservasi2 = QPushButton("11.00-13.00", self)
        self.btn_reservasi2.resize(150, 50)
        self.btn_reservasi2.move(280, 150)
        self.btn_reservasi2.clicked.connect(lambda: self.pilihWaktu("11.00-13.00"))

        self.btn_reservasi3 = QPushButton("14.00-16.00", self)
        self.btn_reservasi3.resize(150, 50)
        self.btn_reservasi3.move(460, 150)
        self.btn_reservasi3.clicked.connect(lambda: self.pilihWaktu("14.00-16.00"))

        self.btn_reservasi4 = QPushButton("17.00-19.00", self)
        self.btn_reservasi4.resize(150, 50)
        self.btn_reservasi4.move(640, 150)
        self.btn_reservasi4.clicked.connect(lambda: self.pilihWaktu("17.00-19.00"))

        self.btn_reservasi5 = QPushButton("20.00-22.00", self)
        self.btn_reservasi5.resize(150, 50)
        self.btn_reservasi5.move(820, 150)
        self.btn_reservasi5.clicked.connect(lambda: self.pilihWaktu("20.00-22.00"))

        self.label_pilih_meja = QLabel(self)
        self.label_pilih_meja.setText("Pilih meja:")
        self.label_pilih_meja.resize(100, 30)
        self.label_pilih_meja.move(100, 250)

        self.btn_meja1 = QPushButton("1", self)
        self.btn_meja1.resize(150, 50)
        self.btn_meja1.move(100, 300)
        self.btn_meja1.clicked.connect(lambda: self.pilihMeja("1"))

        self.btn_meja2 = QPushButton("2", self)
        self.btn_meja2.resize(150, 50)
        self.btn_meja2.move(280, 300)
        self.btn_meja2.clicked.connect(lambda: self.pilihMeja("2"))

        self.btn_meja3 = QPushButton("3", self)
        self.btn_meja3.resize(150, 50)
        self.btn_meja3.move(460, 300)
        self.btn_meja3.clicked.connect(lambda: self.pilihMeja("3"))

        self.btn_meja4 = QPushButton("4", self)
        self.btn_meja4.resize(150, 50)
        self.btn_meja4.move(640, 300)
        self.btn_meja4.clicked.connect(lambda: self.pilihMeja("4"))

        self.btn_meja5 = QPushButton("5", self)
        self.btn_meja5.resize(150, 50)
        self.btn_meja5.move(820, 300)
        self.btn_meja5.clicked.connect(lambda: self.pilihMeja("5"))

        self.btn_meja6 = QPushButton("6", self)
        self.btn_meja6.resize(150, 50)
        self.btn_meja6.move(100, 400)
        self.btn_meja6.clicked.connect(lambda: self.pilihMeja("6"))

        self.btn_meja7 = QPushButton("7", self)
        self.btn_meja7.resize(150, 50)
        self.btn_meja7.move(280, 400)
        self.btn_meja7.clicked.connect(lambda: self.pilihMeja("7"))

        self.btn_meja8 = QPushButton("8", self)
        self.btn_meja8.resize(150, 50)
        self.btn_meja8.move(460, 400)
        self.btn_meja8.clicked.connect(lambda: self.pilihMeja("8"))

        self.btn_meja9 = QPushButton("9", self)
        self.btn_meja9.resize(150, 50)
        self.btn_meja9.move(640, 400)
        self.btn_meja9.clicked.connect(lambda: self.pilihMeja("9"))

        self.btn_meja10 = QPushButton("10", self)
        self.btn_meja10.resize(150, 50)
        self.btn_meja10.move(820, 400)
        self.btn_meja10.clicked.connect(lambda: self.pilihMeja("10"))

        self.btn_selanjutnya = QPushButton("Selanjutnya", self)
        self.btn_selanjutnya.resize(150, 50)
        self.btn_selanjutnya.move(100, 500)
        self.btn_selanjutnya.clicked.connect(self.selanjutnyaClicked)
        self.btn_selanjutnya.setEnabled(False)

        self.btn_waktu_terpilih = None
        self.btn_meja_terpilih = None
        self.label_pilih_waktu.raise_()
        self.label_welcome.raise_()


    def pilihWaktu(self, waktu):
        if self.btn_waktu_terpilih:
            self.btn_waktu_terpilih.setStyleSheet("")

        self.waktu_terpilih = waktu
        self.btn_waktu_terpilih = self.sender()
        self.btn_waktu_terpilih.setStyleSheet("background-color: grey")

        self.cekPilihan()

    def pilihMeja(self, meja):
        if self.btn_meja_terpilih:
            self.btn_meja_terpilih.setStyleSheet("")

        self.meja_terpilih = meja
        self.btn_meja_terpilih = self.sender()
        self.btn_meja_terpilih.setStyleSheet("background-color: grey")

        self.cekPilihan()

    def cekPilihan(self):
        if self.waktu_terpilih and self.meja_terpilih:
            self.btn_selanjutnya.setEnabled(True)
        else:
            self.btn_selanjutnya.setEnabled(False)

    def selanjutnyaClicked(self):
        confirm_msg = QMessageBox(self)
        confirm_msg.setIcon(QMessageBox.Question)
        confirm_msg.setWindowTitle("Konfirmasi Pemesanan")
        confirm_msg.setText(
            f"Anda telah memilih waktu {self.waktu_terpilih} dan meja {self.meja_terpilih}. Lanjutkan ke pembayaran?")
        confirm_msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        confirm_msg.buttonClicked.connect(self.handle_confirmation)
        confirm_msg.exec_()

    def handle_confirmation(self, button):
        if button.text() == "&Yes":
            # Tutup jendela konfirmasi
            self.close_message_board()
            # Tutup jendela RestoranApp
            self.close()
            # Tampilkan jendela CashBankApp
            self.cashbank_window = CashBankApp(self)
            self.cashbank_window.struk_generated.connect(self.show_struk)
            self.cashbank_window.payment_completed.connect(self.handle_payment_completed)
            self.cashbank_window.exec_()
        else:
            self.reset_selection()

    def show_struk(self, username, waktu_terpilih, meja_terpilih, guests):
        # Menutup jendela konfirmasi jika ada
        for widget in QApplication.topLevelWidgets():
            if isinstance(widget, QMessageBox):
                widget.close()

        # Menutup jendela pembayaran jika ada
        if self.cashbank_window:
            self.cashbank_window.close()

        # Menutup jendela pesan jika ada
        if self.message_board:
            self.message_board.close()

        # Menutup jendela struk jika ada
        if self.struk_dialog:
            self.struk_dialog.close()

        # Menampilkan jendela struk dengan memanggil exec_() setelah menginstansiasi
        struk_text = f"=== NOTA PEMESANAN ===\n\n" \
                     f"Atas Nama: {username}\n" \
                     f"Waktu: {waktu_terpilih}\n" \
                     f"Meja: {meja_terpilih}\n" \
                     f"Jumlah Tamu: {guests}\n\n" \
                     f"Terima kasih atas kunjungan Anda!"
        self.struk_dialog = StrukDialog(struk_text)
        self.struk_dialog.exec_()

        # Menutup jendela RestoranApp
        self.close()

    def show_message_board(self):
        self.message_board = MessageBoard("Konfirmasi pemesanan berhasil.")
        self.message_board.exec_()

    def close_message_board(self):
        if self.message_board:
            self.message_board.close()
            self.message_board = None

    def handle_payment_completed(self):
        # Tutup jendela MessageBoard saat pembayaran selesai
        self.close_message_board()

    def reset_selection(self):
        # Atur ulang pemilihan waktu dan meja
        if self.btn_waktu_terpilih:
            self.btn_waktu_terpilih.setStyleSheet("")
            self.btn_waktu_terpilih = None
        if self.btn_meja_terpilih:
            self.btn_meja_terpilih.setStyleSheet("")
            self.btn_meja_terpilih = None
        self.btn_selanjutnya.setEnabled(False)

class RegistrationForm(QWidget):
    registration_successful = pyqtSignal(str, str, int)

    def __init__(self):
        super().__init__()
        self.setWindowTitle('Registration Form')
        self.resize(1000, 600)

        main_layout = QVBoxLayout()
        image_label = QLabel(self)
        pixmap = QPixmap("BOOK YOUR TABLE AT_20240512_012107_0000.png")
        image_label.setPixmap(pixmap)
        image_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(image_label)

        label_name = QLabel('Username', self)
        label_name.move(400, 100)
        label_name.setStyleSheet('font-size: 15px; color: white;')

        self.lineEdit_username = QLineEdit(self)
        self.lineEdit_username.setPlaceholderText('Please enter your username')
        self.lineEdit_username.move(390, 130)
        self.lineEdit_username.resize(300, 40)
        self.lineEdit_username.setStyleSheet('font-size: 18px;')

        label_phone = QLabel('Phone Number', self)
        label_phone.move(400, 200)
        label_phone.setStyleSheet('font-size: 15px; color: white;')

        self.lineEdit_phone = QLineEdit(self)
        self.lineEdit_phone.setPlaceholderText('Please enter your phone number')
        self.lineEdit_phone.move(390, 230)
        self.lineEdit_phone.resize(300, 40)
        self.lineEdit_phone.setStyleSheet('font-size: 18px;')
        phone_validator = QRegExpValidator(QRegExp("\\d{12,13}"))
        self.lineEdit_phone.setValidator(phone_validator)  # Set validator untuk membatasi input hanya angka dengan panjang 12 hingga 13 digit

        label_guests = QLabel('Guests', self)
        label_guests.move(400, 300)
        label_guests.setStyleSheet('font-size: 15px; color: white;')

        self.spinBox_guests = QSpinBox(self)
        self.spinBox_guests.move(390, 330)
        self.spinBox_guests.resize(300, 40)
        self.spinBox_guests.setStyleSheet('font-size: 18px;')
        # Set batas minimal dan maksimal
        self.spinBox_guests.setMinimum(1)
        self.spinBox_guests.setMaximum(4)

        button_register = QPushButton('Register', self)
        button_register.resize(100, 35)
        button_register.move(490, 400)
        button_register.setStyleSheet('font-size: 20px;')
        button_register.clicked.connect(self.register_user)

        main_layout.addStretch(1)

        self.setLayout(main_layout)
        self.username = None

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        color = QColor(255, 255, 255, 150)
        painter.setBrush(color)
        painter.setPen(color)
        painter.drawRoundedRect(300, 50, 700, 500, 100, 100)

    def register_user(self):
        username = self.lineEdit_username.text().strip()
        phone = self.lineEdit_phone.text().strip()
        guests = self.spinBox_guests.value()

        if not username:
            self.show_message('Error', 'Please enter your username.')
            return

        if len(phone) < 12:
            self.show_message('Error', 'Phone number must be at least 12 digits.')
            return

        if not phone.isdigit():
            self.show_message('Error', 'Phone number must only contain digits.')
            return

        self.show_message('Success', f'Registration successful. You have registered for {guests} guests.')
        self.registration_successful.emit(username, phone, guests)
        self.hide()

    def show_message(self, title, message):
        msg = QMessageBox()
        msg.setWindowTitle(title)
        msg.setText(message)
        msg.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    registration_form = RegistrationForm()


    def show_restoran_app(username, phone, guests):
        restoran_window = RestoranApp()
        restoran_window.username = username
        restoran_window.phone = phone
        restoran_window.guests = guests
        restoran_window.show()

        def show_cashbank():
            restoran_window.cashbank_window = CashBankApp(restoran_window)
            restoran_window.cashbank_window.struk_generated.connect(show_struk)
            restoran_window.cashbank_window.payment_completed.connect(restoran_window.handle_payment_completed)
            restoran_window.cashbank_window.payment_completed.connect(show_struk)
            restoran_window.cashbank_window.exec_()

        def show_struk(username, waktu_terpilih, meja_terpilih, guests):
            struk_text =f"Username: {username}\n" \
                        f"Waktu: {waktu_terpilih}\n" \
                        f"Meja: {meja_terpilih}\n" \
                        f"Pengunjung: {guests}\n\n" \
                        f"Terima Kasih Telah Melakukan Reservasi!"


            restoran_window.struk_dialog = StrukDialog(struk_text)
            restoran_window.struk_dialog.exec_()

        restoran_window.show_cashbank = show_cashbank
        restoran_window.show_struk = show_struk


    registration_form.registration_successful.connect(show_restoran_app)

    registration_form.show()

    sys.exit(app.exec_())
